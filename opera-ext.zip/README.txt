+--------- To Install: ----------
|
|
| 1) Unzip this .zip file to your Desktop.
|
| 2) Open Opera.
|
| 3) Press Ctrl+Alt+E
|
| 4) Click 'Developer Mode'.
|
| 5) Drag the folder you Unzipped into the screen.
|
| 6) Enjoy quick access to JayCode.org by clicking on the Icon on the right of your address bar!
|
|
+---------------------------------
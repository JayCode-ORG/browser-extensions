+--------- To Install: ----------
|
|
| 1) Unzip this .zip file to your Desktop
|
| 2) Open Chrome
|
| 3) Go to chrome://extensions
|
| 4) Enable Developer Extensions
|
| 5) Click 'Load unpacked Extension'
|
| 6) Double-click on the folder you just unzipped
|
| 7) Enjoy quick access to JayCode.org by clicking on the Icon on the right of your address bar!
|
|
+---------------------------------